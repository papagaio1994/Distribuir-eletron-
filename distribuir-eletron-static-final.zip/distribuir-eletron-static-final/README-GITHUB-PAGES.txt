Versão atualizada pronta para GitHub Pages.

Ficheiros a colocar no repositório:
- index.html
- style.css
- script.js

Como atualizar no GitHub:
1. Entra no teu repositório.
2. Faz upload destes 3 ficheiros por cima dos anteriores.
3. Confirma o commit.
4. Espera 1 a 3 minutos.
5. Atualiza o link do GitHub Pages com Ctrl+F5.

Nota:
- O ficheiro tem de se chamar exatamente index.html
- Os 3 ficheiros devem estar na raiz do repositório
